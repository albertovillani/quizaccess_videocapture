<?php
// This file was auto-generated from sdk-root/src/data/directconnect/2012-10-25/smoke.json
return [ 'version' => 1, 'defaultRegion' => 'us-west-2', 'testCases' => [ [ 'operationName' => 'DescribeConnections', 'input' => [], 'errorExpectedFromService' => false, ], [ 'operationName' => 'DescribeConnections', 'input' => [ 'connectionId' => 'fake-connection', ], 'errorExpectedFromService' => true, ], ],];
