<?php
// This file was auto-generated from sdk-root/src/data/robomaker/2018-06-29/paginators-1.json
return [ 'pagination' => [],];
