<?php
// This file was auto-generated from sdk-root/src/data/kinesisanalyticsv2/2018-05-23/paginators-1.json
return [ 'pagination' => [],];
