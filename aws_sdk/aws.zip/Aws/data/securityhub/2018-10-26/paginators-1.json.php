<?php
// This file was auto-generated from sdk-root/src/data/securityhub/2018-10-26/paginators-1.json
return [ 'pagination' => [ 'GetFindings' => [ 'input_token' => 'NextToken', 'output_token' => 'NextToken', 'limit_key' => 'MaxResults', ], 'GetInsights' => [ 'input_token' => 'NextToken', 'output_token' => 'NextToken', 'limit_key' => 'MaxResults', ], 'ListEnabledProductsForImport' => [ 'input_token' => 'NextToken', 'output_token' => 'NextToken', 'limit_key' => 'MaxResults', ], ],];
