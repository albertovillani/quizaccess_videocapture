<?php
// This file was auto-generated from sdk-root/src/data/textract/2018-06-27/paginators-1.json
return [ 'pagination' => [],];
